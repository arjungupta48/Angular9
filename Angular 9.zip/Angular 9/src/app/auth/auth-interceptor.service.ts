import { Injectable } from '@angular/core';
import {
    HttpInterceptor, 
    HttpRequest, 
    HttpHandler,
    HttpParams
} from '@angular/common/http';

import { AuthService } from './auth.service';
import { exhaustMap, take } from 'rxjs/operators';

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {
    constructor(private authService: AuthService) {}

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        return this.authService.user.pipe(
            take(1),            //take(1) gets 1 user and then unsubscribes| exhaustMap take user observable then http observable
            exhaustMap(user => {
                //If we don't have a user, then son't add params (Login and Sihnup case) that time user is null
                if(!user) {
                    return next.handle(req);
                }
                const modifiedReq = req.clone({
                    params: new HttpParams().set('auth', user.token)
                });
                return next.handle(modifiedReq);
            })
        );
    }


}