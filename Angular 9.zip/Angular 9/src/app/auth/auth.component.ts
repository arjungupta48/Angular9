import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs'; 

import { AuthService, AuthResponseData } from './auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  isLoginMode = true;
  isLoading = false;
  error: string = null;

  constructor(private authServie: AuthService, private router: Router) { }

  ngOnInit(): void {
  }

  onSwitchMode() {
    this.isLoginMode = !this.isLoginMode;
  }

  onSubmit(form: NgForm) {
    //console.log(form.value);

    if(!form.valid) { //we already disable button when form is not valid, but can be changed from Browser Developer Tools. Hence this logic
      return;
    }
    const email = form.value.email;
    const passowrd = form.value.password;

    let authObs: Observable<AuthResponseData>;   //authObs to reduce duplicate code in both subscirbe method in if and else case. Now we subscribe after if else condition. Hence, reducing same repetitive code

    this.isLoading = true;

    if (this.isLoginMode) {
      authObs = this.authServie.login(email, passowrd);
    } else {
      authObs = this.authServie.signup(email, passowrd);
    }

    authObs.subscribe(
      resData => {
        console.log(resData);
        this.isLoading = false;
        this.router.navigate(['/recipes']);
    }, 
    errorMessage => {
      console.log(errorMessage);
      this.error = errorMessage;
      this.isLoading = false;
    }
  );

    form.reset();
  }

}
