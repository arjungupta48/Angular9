export class Ingredient {
    // public name: string;
    // public amount: number;

    // constructor(name: string, amount: number) {
    //     this.name = name;
    //     this.amount = amount;
    // }

    // below is shortcut of above code by just adding 'public' keyword

    constructor(public name: string, public amount: number) {}
}