import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, tap, take, exhaustMap } from 'rxjs/operators';
import { pipe } from 'rxjs';

import { RecipeService } from '../recipes/recipe.service';
import { Recipe } from '../recipes/recipe.model';
import { AuthService } from '../auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class DataStorageService {

  constructor(
    private http: HttpClient, 
    private recipeService: RecipeService, 
    private authService: AuthService
  ) { }

  storeRecipes() {
    const recipes = this.recipeService.getRecipes();

    //in firebase sending a PUT request OVERRIDES all existing data with the new sent data
    //we can use https://ng-course-recipe-book-d907b.firebaseio.com/ this url and add /recipes.json 
    //which creates recipes folder in firebase (this is how firebase works)

    this.http
        .put('https://ng-course-recipe-book-d907b.firebaseio.com/recipes.json', recipes)
        .subscribe(response => {
          console.log(response);
        });
  }

  fetchRecipes() {
    return this.http
          .get<Recipe[]>('https://ng-course-recipe-book-d907b.firebaseio.com/recipes.json',
        )
      .pipe(
        map(recipes => {
          return recipes.map(recipe => {
            return {
              ...recipe, 
              ingredients: recipe.ingredients ? recipe.ingredients : []
             };
            });
          }),
          tap(recipes => {
          this.recipeService.setRecipes(recipes);
        }));
        //map operator(rxjs map) allows us to transform data in an observable chain
        //second one is javascript map, allows us to transforma n element in an Array | If ingredients is not fetched from service
        //then adds an empty array to avoid getting errors (Eg: while creating neww recipe, if we dont add ingredients and click on save data)
        //in that case error might occur while fetching data, since we define it of type get<Recipe[]>
      }

}
