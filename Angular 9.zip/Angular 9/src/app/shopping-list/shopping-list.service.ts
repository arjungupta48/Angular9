import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { Ingredient } from '../shared/ingredient.model';

@Injectable({
  providedIn: 'root' //declaring like this is eqivalent of declaring in providers array of app.module.ts file
})
export class ShoppingListService {
  ingredientsChanged = new Subject<Ingredient[]>(); //Subject<Recipe> works same as EventEmitter | In place of 'emit' method of EvenEmitter now we use 'next' method
  //Subject is used when doing cross component communication
  startedEditing = new Subject<number>();
  
  private ingredients: Ingredient[] = [
    new Ingredient('Apples', 5),
    new Ingredient('Tomatoes', 10),
  ];

  getIngredients() {
    return this.ingredients.slice(); //using slice() so that we do not access the original array stored in this service. We only access a copy of ingredients array by using slice()
  }

  getIngredient(index: number) {
    return this.ingredients[index];
  }

  addIngredient(ingredient: Ingredient) {
    this.ingredients.push(ingredient);
    this.ingredientsChanged.next(this.ingredients.slice()); // to update recently added ingredient and reflect in browser
  }

  addIngredients(ingredients: Ingredient[]) {
    this.ingredients.push(...ingredients);  // ... es6 notation converts array of objects to a LIST and then we push it
    this.ingredientsChanged.next(this.ingredients.slice());
  }

  updateIngredient(index: number, newIngredient: Ingredient) {
    this.ingredients[index] = newIngredient;
    this.ingredientsChanged.next(this.ingredients.slice());
  }

  deleteIngredient(index: number) {
    this.ingredients.splice(index, 1);
    this.ingredientsChanged.next(this.ingredients.slice());
  }

}
