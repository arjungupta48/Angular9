import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { Recipe } from './recipe.model';
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';

@Injectable({         //Now while navigating ShoppingList Service instamce of RecipeList was getting destroyed and a new was created upon coming back to recipe service. So, we provide in root component (app.module.ts or like this)
  providedIn: 'root'  //Earlier we do not wanted entire application to have this service available as of now
})                   // so we have specified in recipe component, so it will be available to all its childs also, like recipe-list and recipe-detail
@Injectable()
export class RecipeService {
  recipesChanged = new Subject<Recipe[]>();

  // private recipes: Recipe[] = [
  //   new Recipe(
  //     'Tasty Maggie', 
  //     'A super-tasty Maggie - just awesome!', 
  //     '../assets/maggie.jpg',
  //     [
  //       new Ingredient('Noodles', 2),
  //       new Ingredient('Maggie Masala', 2)
  //     ]),
  //   new Recipe(
  //     'American Cheese Burger', 
  //     'A mouth watering hamburger', 
  //     '../assets/burger.jpg',
  //     [
  //       new Ingredient('Buns', 2),
  //       new Ingredient('Veggies', 1)
  //     ])
  // ];

  private recipes: Recipe[] = [];

  constructor(private shoppingListService: ShoppingListService) { }

  setRecipes(recipes: Recipe[]) {
    this.recipes = recipes;
    this.recipesChanged.next(this.recipes.slice());
  }

  getRecipes() {
    return this.recipes.slice(); //using slice() so that we do not access the original array stored in this service. We only access a copy of recipes array by using slice()
  }

  getRecipe(index: number) {
    return this.recipes[index];
  }

  addIngredientsToShoppingList(ingredients: Ingredient[]) {
    this.shoppingListService.addIngredients(ingredients);
  }

  addRecipe(recipe: Recipe) {
    this.recipes.push(recipe);
    this.recipesChanged.next(this.recipes.slice());
  }

  updateRecipe(index: number, newRecipe: Recipe) {
    this.recipes[index] = newRecipe;
    this.recipesChanged.next(this.recipes.slice());
  }

  deleteRecipe(index: number){
    this.recipes.splice(index, 1);
    this.recipesChanged.next(this.recipes.slice());
  }

}
