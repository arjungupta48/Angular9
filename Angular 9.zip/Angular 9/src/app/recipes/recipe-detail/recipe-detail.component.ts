import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { Recipe } from '../recipe.model';
import { RecipeService } from '../recipe.service';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {
  recipe: Recipe;
  id: number;

  constructor(private recipeService: RecipeService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    //const id = this.route.snapshot.params['id']; //use this code when ID value is not changing within this component

    this.route.params                             // this is dynamic way (when ID value changes within the component)
        .subscribe(
          (params: Params) => {
            this.id = +params['id'];
            this. recipe = this.recipeService.getRecipe(this.id);
          }
        );
  }

  onAddToShoppingList() {
     this.recipeService.addIngredientsToShoppingList(this.recipe.ingredients);
  }

  onEditRecipe() {
    this.router.navigate(['edit'], { relativeTo: this.route});
    //this.router.navigate(['../', this.id, 'edit'], { relativeTo: this.route});  //both are same, this approach is going 1 level up and making use of ID
  }

  onDeleteRecipe() {
    this.recipeService.deleteRecipe(this.id);
    this.router.navigate(['/recipes']);
  }

}
